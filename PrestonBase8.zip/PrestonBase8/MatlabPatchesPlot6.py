import zipfile
import os.path
def openFile(filename):
  if (  os.path.isfile("out.zip") ):
     z = zipfile.ZipFile("out.zip", "r")
     f = z.open(filename)     
  else:
    f = open(filename)  
  return f
		  

from matplotlib import pyplot as plt
from matplotlib import cm as cm
import matplotlib.colors as colors
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import matplotlib.image as mpimg
from numpy import * 
import pylab 

import sqlite3 as lite
import sys

import matplotlib.dates as mdates  
from datetime import datetime, date, time
from matplotlib.legend_handler import HandlerLine2D


Tsfc_Facets = []
TCAN_ITEM=16
TA_ITEM=17  
with openFile('Tsfc_Facets.out') as f:
  count = 0
  for line in f:
    if (count == 0):
      count = count + 1
      continue
    line = line.split() # to deal with blank
    if line:            # lines (ie skip them)
      line = [float(i) for i in line]
      Tsfc_Facets.append(line) 
    count = count + 1
    		
    		
def isBlank(value):
	  if value == '':
	    value = pylab.nan
	  return value
    		
def annotateGraph(time):
  try:
    con = None
    con = lite.connect('/home/kerryn/Documents/Work/Data/CityOfMelbourne2011-12/CoM-2011-2.db')
    cur = con.cursor()  
    #print sql
    cur.execute(sql)
    rows = cur.fetchall()
    #print rows[0][0],rows[0][1],rows[0][2], rows[0][3],rows[0][4],rows[0][5], rows[0][6],rows[0][7],rows[0][8]
    return rows  
  except lite.Error, e:
    print "Error %s:" % e.args[0]
    sys.exit(1)    
  finally:    
    if con:
        con.close()
 
 
#define a pulse
def pulse(x, mid, width_top, width_bottom):
    if abs(mid-x)<.5*width_top: 
        return 1.0; 
    elif abs(mid-x)<.5*width_bottom:
        if (x>mid): 
            return 1.-2*(x-(mid+.5*width_top))/(width_bottom-width_top);
        else: 
            return 1.-2*((mid-.5*width_top)-x)/(width_bottom-width_top);
    else: 
        return 0.;
		  
#generate pulse train
#t = arange(0,1,.005) 
t = linspace(0,1,9) 
pr = array([pulse(i,.75,.245,.75) for i in t])
pg = array([pulse(i,.5,.245,.75) for i in t]) 
pb = array([pulse(i,.25,.245,.75) for i in t]) 
newcolors = [(pr[i],pg[i],pb[i]) for i in range(len(pr))] 
		
import subprocess

def min(list):
  min = list[0]
  for elm in list[1:]:
    if elm < min:
      min = elm
  #print "The minimum value in the list is: " + str(min)
  return min[0]
		  
def max(list):
  max = list[0]
  for elm in list[1:]:
    if elm > max:
      max = elm
  #print "The maximum value in the list is: " + str(max)
  return max[0]
		  
with openFile('lp31_bhbl150_vertices_toMatlab.out') as f:
    P = []
    for line in f:
        line = line.split() # to deal with blank
        if line:            # lines (ie skip them)
            line = [float(i) for i in line]
            P.append(line)

with openFile('lp31_bhbl150_faces_toMatlab.out') as f:
    F = []
    for line in f:
        line = line.split() # to deal with blank
        if line:            # lines (ie skip them)
            line = [float(i) for i in line]
            F.append(line)

def getColors(m,a):
    b=m.to_rgba(a)
    #print a
    return [(i[0],i[1],i[2]) for i in b]
    		
    		
def getFaceMidpointsZ(pc):
    a=[]
    		
    for i in pc:
        v=0
        for j in i:
            v=v+j[2]
        v=v/4.
        a.append(v)
    return a
    		
def getColorList(z,minValue,maxValue,cmap):
    zlen=len(z)
    valueRange = maxValue - minValue
    colorArray = [[]] * zlen
    for count in range(0,zlen):
      colorValue = (z[count][0] - minValue) / valueRange
      #print colorValue
      temp = cmap(colorValue)
      colorArray[count]=temp
    return colorArray
    		
## get first face values 1,2,3,4 map to vertices 1,2,3,4
## color value is face[i]
fListLength = len(F)
		
#fListLength = 5
		
pc = [[]] * fListLength
colorArray = [[]] * fListLength
for count in range(0,fListLength):
  temp=P[-1+int(F[count][0])],P[-1+int(F[count][1])],P[-1+int(F[count][2])],P[-1+int(F[count][3])]
  pc[count]=temp
		  
#Create a color map that goes from blue to white to red
cdict = {'red':   ((0,    0, 0),  #i.e. at value 0, red component is 0. First parameter is the value, second is the color component. Ignore the third parameter, it is for discontinuities.
                   (0.5,  1, 1),  #     at value 0.5, red component is 1.
                   (1,    1, 1)), #     at value 1, red component is 1
         'green': ((0,    0, 0),
                   (0.5,  1, 1),
                   (1,    0, 0)),
         'blue':  ((0,    1, 1),
                   (0.5,  1, 1),
                   (1,    0, 0))}

def findNearestNeighbors(x,y,z):
  neighbors = []
  face1=findFace(x,y-1,z)
  face2=findFace(x,y+1,z)
  face3=findFace(x-1,y,z)
  face4=findFace(x+1,y,z)
		  
  face0 = findFace(x, y, z)
  if (face0 >= 0):
    neighbors.append(face0)
  
  if (face1 >= 0):
    neighbors.append(face1)
  if (face2 >= 0):
    neighbors.append(face2)
  if (face3 >= 0):
    neighbors.append(face3)
  if (face4 >= 0):
    neighbors.append(face4)
    
  return neighbors
		  
def getNeighborsAverage(neighbors,values):
  lenNeighbors = len(neighbors)
  total = 0		     
  for count in range(0,lenNeighbors):
    total = total + values[ neighbors[count] ][0]
  return total / lenNeighbors
		  

def findFace(x, y, z):
  faceToFind = -9999
  corners = []
  corner1=0
  corner2=0
  corner3=0
  corner4=0
  pListLength = len(P)
  z1 = z + 0.5
  x1 = x - 0.5
  x2 = x + 0.5
  y1 = y - 0.5
  y2 = y + 0.5
		  
  for count in range(0,pListLength):
	  
    #match x1,y1,z1
    if (P[count][0] == x1 and P[count][1] == y1 and P[count][2] == z1 ):
      corner1=count+1
    if (P[count][0] == x1 and P[count][1] == y2 and P[count][2] == z1 ):
      corner2=count+1
    if (P[count][0] == x2 and P[count][1] == y1 and P[count][2] == z1 ):
      corner3=count+1
    if (P[count][0] == x2 and P[count][1] == y2 and P[count][2] == z1 ):
      corner4=count+1
    		  
  #print corner1, corner2, corner3, corner4
  corners.append(corner1)
  corners.append(corner2)
  corners.append(corner3)
  corners.append(corner4)
  cornersSort = sorted(corners)
		  
  fListLength = len(F)
  for count in range(0,fListLength):
    if ( sorted( F[count] ) == cornersSort ):
      faceToFind=count
    		  
  return faceToFind	
		  
def drawGraph(tim,label):
  from datetime import datetime, date, time
  
  # label='2012-01-31-0300'
  year = label[0 : 4]
  month = label[5 : 5 + 2]
  day = label[8 : 8 + 2]
  hour = label[11 : 11 + 2]
  minute = label[13 : 13 + 2]
		  
  d = date(int(year), int(month), int(day))
  t = time(int(hour), int(minute))
  dateTimeofData = datetime.combine(d, t)
		  
  try:
    f = openFile('toMatlab_utci_tim' + tim + '.out')
  except IOError:
    return
  except KeyError:
    return
		  
  with openFile('toMatlab_utci_tim' + tim + '.out') as f:
    utci = []
    for line in f:
        line = line.split() # to deal with blank
        if line:            # lines (ie skip them)
            line = [float(i) for i in line]
            utci.append(line)
  
		  
  with openFile('toMatlab_tmrt_tim' + tim + '.out') as f:
    tmrt = []
    for line in f:
        line = line.split() # to deal with blank
        if line:            # lines (ie skip them)
            line = [float(i) for i in line]
            tmrt.append(line)
  
  with openFile('toMatlab_Tsfc_yd040_lp31_bhbl150_lat38S_stror00_tim' + tim + '.out') as f:
    tsfc = []
    for line in f:
        line = line.split() # to deal with blank
        if line:            # lines (ie skip them)
            line = [float(i) for i in line]
            tsfc.append(line)              
  #z=tsfc
  tsfcListLength = len(utci)
  rowNumber = int(tim)/100
  degree=u'\N{DEGREE SIGN}''C'
		  
  year = label[0 : 4]
  month = label[5 : 5 + 2]
  day = label[8 : 8 + 2]
  time = label[11 : 11 + 4]
  timecode=year + '' + month + '' + day + '' + time
		  
		
daysAndTimesTotal=[]  
		
daysAndTimes=[]  
		

def drawAggGraphs():
  #import datetime as datetime
  dayCount = 0
  #print daysAndTimesTotal
  length = len(daysAndTimesTotal)
  	  
  #d = date(int(2000), int(1), int(1))
  #t = time(int(1), int(00))
  #dateTimeData = datetime.combine(d, t)
  	  
  #datesToPlot= [dateTimeData] * 24
  datesToPlot = []
  day = 1
  for count in range(0,24):
    #print count
    if (count == 24):
      hour = 0
      day = day + 1
    else:
      hour = count
    d = date(int(2000), int(1), int(day))
    t = time(int(hour), int(00))
    dateTimeData = datetime.combine(d, t)
    #datesToPlot[count] = dateTimeData
    datesToPlot.append(dateTimeData)
    
  
  for count in range(0,length):   
    hour = daysAndTimesTotal[count].hour
    if (hour == 0):
      dayCount = dayCount + 1
    #print hour
    		
  #print tmrtEM5TotalAgg
  #print tmrtEM11TotalAgg
  #print tmrtEM8TotalAgg
  #print petEM5TotalAgg
  #print petEM11TotalAgg
  #print petEM8TotalAgg
  #print surftempEM5TotalAgg
  #print utcitempEM5TotalAgg
  #print surftempEM11TotalAgg
  #print utcitempEM11TotalAgg
  #print surftempEM8TotalAgg
  #print utcitempEM8TotalAgg
  #print surftempEM5NTotalAgg
  #print utcitempEM5NTotalAgg
  #print surftempEM11NTotalAgg
  #print utcitempEM11NTotalAgg
  #print surftempEM8NTotalAgg
  #print utcitempEM8NTotalAgg
  #print surftempTmrtEM5NTotalAgg
  #print surftempTmrtEM11NTotalAgg
  #print surftempTmrtEM8NTotalAgg
  
  fig = plt.figure()
  fig.set_dpi(100)
  fig.set_size_inches(15.36, 9.00)
  
  	  
  plt.title("PrestonBase8 30 day average - observations vs. VTUF - " + label)
  plt.ylabel("temp C")
  plt.grid(True)
  plt.legend(fontsize=8,bbox_to_anchor=(0.12, 1),handler_map={utcitempPlotEM5N: HandlerLine2D(numpoints=2)})
  #plt.show()
  plt.savefig('30DayComparison' + '_' + label + '.png')
  plt.close()
 

  tmrtObsTotalAggAve= [0.0] * 24
  utciObsTotalAggAve= [0.0] * 24
  utcitempVtufTotalAggAve= [0.0] * 24
  tmrtVtufTotalAggAve= [0.0] * 24
  for count in range(0,24):
	    		
	fig = plt.figure()
	fig.set_dpi(100)
	fig.set_size_inches(15.36, 9.00)
                                 
	utcitempPlotEM5NAve, = plt.plot_date(x=datesToPlot, y=utcitempVtufTotalAggAve, fmt="bo-", label='UTCI ave VTUF', ls="dotted", linewidth=2)
	pettempPlotEM5Ave, = plt.plot_date(x=datesToPlot, y=utciObsTotalAggAve, fmt="bx-", label='UTCI ave Obs')
	surftempTmrtPlotEM5NAve, = plt.plot_date(x=datesToPlot, y=tmrtVtufTotalAggAve, fmt="ro-", label='Tmrt ave VTUF', ls="dotted", linewidth=2)
	tmrttempPlotEM5Ave, = plt.plot_date(x=datesToPlot, y=tmrtObsTotalAggAve, fmt="rx-", label='Tmrt ave Obs')
			  
	plt.title("PrestonBase8 30 day average - ave observations vs. ave VTUF - " + label)
	plt.ylabel("temp C")
	plt.grid(True)
	plt.legend(fontsize=8,bbox_to_anchor=(0.12, 1),handler_map={utcitempPlotEM5NAve: HandlerLine2D(numpoints=2)})
	plt.savefig('30DayComparisonAve' + '_' + label + '.png')
	plt.close()  		

tim='0000'
label='2004-02-09-0000'
drawGraph(tim,label)
tim='0100'
label='2004-02-09-0100'
drawGraph(tim,label)
tim='0200'
label='2004-02-09-0200'
drawGraph(tim,label)
tim='0300'
label='2004-02-09-0300'
drawGraph(tim,label)
tim='0400'
label='2004-02-09-0400'
drawGraph(tim,label)
tim='0500'
label='2004-02-09-0500'
drawGraph(tim,label)
tim='0600'
label='2004-02-09-0600'
drawGraph(tim,label)
tim='0700'
label='2004-02-09-0700'
drawGraph(tim,label)
tim='0800'
label='2004-02-09-0800'
drawGraph(tim,label)
tim='0900'
label='2004-02-09-0900'
drawGraph(tim,label)
tim='1000'
label='2004-02-09-1000'
drawGraph(tim,label)
tim='1100'
label='2004-02-09-1100'
drawGraph(tim,label)
tim='1200'
label='2004-02-09-1200'
drawGraph(tim,label)
tim='1300'
label='2004-02-09-1300'
drawGraph(tim,label)
tim='1400'
label='2004-02-09-1400'
drawGraph(tim,label)
tim='1500'
label='2004-02-09-1500'
drawGraph(tim,label)
tim='1600'
label='2004-02-09-1600'
drawGraph(tim,label)
tim='1700'
label='2004-02-09-1700'
drawGraph(tim,label)
tim='1800'
label='2004-02-09-1800'
drawGraph(tim,label)
tim='1900'
label='2004-02-09-1900'
drawGraph(tim,label)
tim='2000'
label='2004-02-09-2000'
drawGraph(tim,label)
tim='2100'
label='2004-02-09-2100'
drawGraph(tim,label)
tim='2200'
label='2004-02-09-2200'
drawGraph(tim,label)
tim='2300'
label='2004-02-09-2300'
drawGraph(tim,label)

#print surftemp
#print utcitemp
#print daysAndTimes
fig = plt.figure()
fig.set_dpi(100)
fig.set_size_inches(15.36, 9.00)


plt.title("PrestonBase8 observations vs. VTUF - " + label)
plt.ylabel("temp C")
plt.grid(True)
#plt.show()
plt.savefig('Comparison' + tim + '_' + label + '.png')
plt.close()



daysAndTimes=[]

tim='2400'
label='2004-02-10-0000'
drawGraph(tim,label)
tim='2500'
label='2004-02-10-0100'
drawGraph(tim,label)
tim='2600'
label='2004-02-10-0200'
drawGraph(tim,label)
tim='2700'
label='2004-02-10-0300'
drawGraph(tim,label)
tim='2800'
label='2004-02-10-0400'
drawGraph(tim,label)
tim='2900'
label='2004-02-10-0500'
drawGraph(tim,label)
tim='3000'
label='2004-02-10-0600'
drawGraph(tim,label)
tim='3100'
label='2004-02-10-0700'
drawGraph(tim,label)
tim='3200'
label='2004-02-10-0800'
drawGraph(tim,label)
tim='3300'
label='2004-02-10-0900'
drawGraph(tim,label)
tim='3400'
label='2004-02-10-1000'
drawGraph(tim,label)
tim='3500'
label='2004-02-10-1100'
drawGraph(tim,label)
tim='3600'
label='2004-02-10-1200'
drawGraph(tim,label)
tim='3700'
label='2004-02-10-1300'
drawGraph(tim,label)
tim='3800'
label='2004-02-10-1400'
drawGraph(tim,label)
tim='3900'
label='2004-02-10-1500'
drawGraph(tim,label)
tim='4000'
label='2004-02-10-1600'
drawGraph(tim,label)
tim='4100'
label='2004-02-10-1700'
drawGraph(tim,label)
tim='4200'
label='2004-02-10-1800'
drawGraph(tim,label)
tim='4300'
label='2004-02-10-1900'
drawGraph(tim,label)
tim='4400'
label='2004-02-10-2000'
drawGraph(tim,label)
tim='4500'
label='2004-02-10-2100'
drawGraph(tim,label)
tim='4600'
label='2004-02-10-2200'
drawGraph(tim,label)
tim='4700'
label='2004-02-10-2300'
drawGraph(tim,label)

#print surftemp
#print utcitemp
#print daysAndTimes
fig = plt.figure()
fig.set_dpi(100)
fig.set_size_inches(15.36, 9.00)


plt.title("PrestonBase8 observations vs. VTUF - " + label)
plt.ylabel("temp C")
plt.grid(True)
#plt.show()
plt.savefig('Comparison' + tim + '_' + label + '.png')
plt.close()



daysAndTimes=[]

tim='4800'
label='2004-02-11-0000'
drawGraph(tim,label)
tim='4900'
label='2004-02-11-0100'
drawGraph(tim,label)
tim='5000'
label='2004-02-11-0200'
drawGraph(tim,label)
tim='5100'
label='2004-02-11-0300'
drawGraph(tim,label)
tim='5200'
label='2004-02-11-0400'
drawGraph(tim,label)
tim='5300'
label='2004-02-11-0500'
drawGraph(tim,label)
tim='5400'
label='2004-02-11-0600'
drawGraph(tim,label)
tim='5500'
label='2004-02-11-0700'
drawGraph(tim,label)
tim='5600'
label='2004-02-11-0800'
drawGraph(tim,label)
tim='5700'
label='2004-02-11-0900'
drawGraph(tim,label)
tim='5800'
label='2004-02-11-1000'
drawGraph(tim,label)
tim='5900'
label='2004-02-11-1100'
drawGraph(tim,label)
tim='6000'
label='2004-02-11-1200'
drawGraph(tim,label)
tim='6100'
label='2004-02-11-1300'
drawGraph(tim,label)
tim='6200'
label='2004-02-11-1400'
drawGraph(tim,label)
tim='6300'
label='2004-02-11-1500'
drawGraph(tim,label)
tim='6400'
label='2004-02-11-1600'
drawGraph(tim,label)
tim='6500'
label='2004-02-11-1700'
drawGraph(tim,label)
tim='6600'
label='2004-02-11-1800'
drawGraph(tim,label)
tim='6700'
label='2004-02-11-1900'
drawGraph(tim,label)
tim='6800'
label='2004-02-11-2000'
drawGraph(tim,label)
tim='6900'
label='2004-02-11-2100'
drawGraph(tim,label)
tim='7000'
label='2004-02-11-2200'
drawGraph(tim,label)
tim='7100'
label='2004-02-11-2300'
drawGraph(tim,label)

#print surftemp
#print utcitemp
#print daysAndTimes
fig = plt.figure()
fig.set_dpi(100)
fig.set_size_inches(15.36, 9.00)


plt.title("PrestonBase8 observations vs. VTUF - " + label)
plt.ylabel("temp C")
plt.grid(True)
#plt.show()
plt.savefig('Comparison' + tim + '_' + label + '.png')
plt.close()



daysAndTimes=[]

tim='7200'
label='2004-02-12-0000'
drawGraph(tim,label)
tim='7300'
label='2004-02-12-0100'
drawGraph(tim,label)
tim='7400'
label='2004-02-12-0200'
drawGraph(tim,label)
tim='7500'
label='2004-02-12-0300'
drawGraph(tim,label)
tim='7600'
label='2004-02-12-0400'
drawGraph(tim,label)
tim='7700'
label='2004-02-12-0500'
drawGraph(tim,label)
tim='7800'
label='2004-02-12-0600'
drawGraph(tim,label)
tim='7900'
label='2004-02-12-0700'
drawGraph(tim,label)
tim='8000'
label='2004-02-12-0800'
drawGraph(tim,label)
tim='8100'
label='2004-02-12-0900'
drawGraph(tim,label)
tim='8200'
label='2004-02-12-1000'
drawGraph(tim,label)
tim='8300'
label='2004-02-12-1100'
drawGraph(tim,label)
tim='8400'
label='2004-02-12-1200'
drawGraph(tim,label)
tim='8500'
label='2004-02-12-1300'
drawGraph(tim,label)
tim='8600'
label='2004-02-12-1400'
drawGraph(tim,label)
tim='8700'
label='2004-02-12-1500'
drawGraph(tim,label)
tim='8800'
label='2004-02-12-1600'
drawGraph(tim,label)
tim='8900'
label='2004-02-12-1700'
drawGraph(tim,label)
tim='9000'
label='2004-02-12-1800'
drawGraph(tim,label)
tim='9100'
label='2004-02-12-1900'
drawGraph(tim,label)
tim='9200'
label='2004-02-12-2000'
drawGraph(tim,label)
tim='9300'
label='2004-02-12-2100'
drawGraph(tim,label)
tim='9400'
label='2004-02-12-2200'
drawGraph(tim,label)
tim='9500'
label='2004-02-12-2300'
drawGraph(tim,label)

#print surftemp
#print utcitemp
#print daysAndTimes
fig = plt.figure()
fig.set_dpi(100)
fig.set_size_inches(15.36, 9.00)


plt.title("PrestonBase8 observations vs. VTUF - " + label)
plt.ylabel("temp C")
plt.grid(True)
#plt.show()
plt.savefig('Comparison' + tim + '_' + label + '.png')
plt.close()



daysAndTimes=[]

tim='9600'
label='2004-02-13-0000'
drawGraph(tim,label)
tim='9700'
label='2004-02-13-0100'
drawGraph(tim,label)
tim='9800'
label='2004-02-13-0200'
drawGraph(tim,label)
tim='9900'
label='2004-02-13-0300'
drawGraph(tim,label)
tim='10000'
label='2004-02-13-0400'
drawGraph(tim,label)
tim='10100'
label='2004-02-13-0500'
drawGraph(tim,label)
tim='10200'
label='2004-02-13-0600'
drawGraph(tim,label)
tim='10300'
label='2004-02-13-0700'
drawGraph(tim,label)
tim='10400'
label='2004-02-13-0800'
drawGraph(tim,label)
tim='10500'
label='2004-02-13-0900'
drawGraph(tim,label)
tim='10600'
label='2004-02-13-1000'
drawGraph(tim,label)
tim='10700'
label='2004-02-13-1100'
drawGraph(tim,label)
tim='10800'
label='2004-02-13-1200'
drawGraph(tim,label)
tim='10900'
label='2004-02-13-1300'
drawGraph(tim,label)
tim='11000'
label='2004-02-13-1400'
drawGraph(tim,label)
tim='11100'
label='2004-02-13-1500'
drawGraph(tim,label)
tim='11200'
label='2004-02-13-1600'
drawGraph(tim,label)
tim='11300'
label='2004-02-13-1700'
drawGraph(tim,label)
tim='11400'
label='2004-02-13-1800'
drawGraph(tim,label)
tim='11500'
label='2004-02-13-1900'
drawGraph(tim,label)
tim='11600'
label='2004-02-13-2000'
drawGraph(tim,label)
tim='11700'
label='2004-02-13-2100'
drawGraph(tim,label)
tim='11800'
label='2004-02-13-2200'
drawGraph(tim,label)
tim='11900'
label='2004-02-13-2300'
drawGraph(tim,label)

#print surftemp
#print utcitemp
#print daysAndTimes
fig = plt.figure()
fig.set_dpi(100)
fig.set_size_inches(15.36, 9.00)


plt.title("PrestonBase8 observations vs. VTUF - " + label)
plt.ylabel("temp C")
plt.grid(True)
#plt.show()
plt.savefig('Comparison' + tim + '_' + label + '.png')
plt.close()



daysAndTimes=[]

tim='12000'
label='2004-02-14-0000'
drawGraph(tim,label)
tim='12100'
label='2004-02-14-0100'
drawGraph(tim,label)
tim='12200'
label='2004-02-14-0200'
drawGraph(tim,label)
tim='12300'
label='2004-02-14-0300'
drawGraph(tim,label)
tim='12400'
label='2004-02-14-0400'
drawGraph(tim,label)
tim='12500'
label='2004-02-14-0500'
drawGraph(tim,label)
tim='12600'
label='2004-02-14-0600'
drawGraph(tim,label)
tim='12700'
label='2004-02-14-0700'
drawGraph(tim,label)
tim='12800'
label='2004-02-14-0800'
drawGraph(tim,label)
tim='12900'
label='2004-02-14-0900'
drawGraph(tim,label)
tim='13000'
label='2004-02-14-1000'
drawGraph(tim,label)
tim='13100'
label='2004-02-14-1100'
drawGraph(tim,label)
tim='13200'
label='2004-02-14-1200'
drawGraph(tim,label)
tim='13300'
label='2004-02-14-1300'
drawGraph(tim,label)
tim='13400'
label='2004-02-14-1400'
drawGraph(tim,label)
tim='13500'
label='2004-02-14-1500'
drawGraph(tim,label)
tim='13600'
label='2004-02-14-1600'
drawGraph(tim,label)
tim='13700'
label='2004-02-14-1700'
drawGraph(tim,label)
tim='13800'
label='2004-02-14-1800'
drawGraph(tim,label)
tim='13900'
label='2004-02-14-1900'
drawGraph(tim,label)
tim='14000'
label='2004-02-14-2000'
drawGraph(tim,label)
tim='14100'
label='2004-02-14-2100'
drawGraph(tim,label)
tim='14200'
label='2004-02-14-2200'
drawGraph(tim,label)
tim='14300'
label='2004-02-14-2300'
drawGraph(tim,label)

#print surftemp
#print utcitemp
#print daysAndTimes
fig = plt.figure()
fig.set_dpi(100)
fig.set_size_inches(15.36, 9.00)


plt.title("PrestonBase8 observations vs. VTUF - " + label)
plt.ylabel("temp C")
plt.grid(True)
#plt.show()
plt.savefig('Comparison' + tim + '_' + label + '.png')
plt.close()



daysAndTimes=[]

tim='14400'
label='2004-02-15-0000'
drawGraph(tim,label)
tim='14500'
label='2004-02-15-0100'
drawGraph(tim,label)
tim='14600'
label='2004-02-15-0200'
drawGraph(tim,label)
tim='14700'
label='2004-02-15-0300'
drawGraph(tim,label)
tim='14800'
label='2004-02-15-0400'
drawGraph(tim,label)
tim='14900'
label='2004-02-15-0500'
drawGraph(tim,label)
tim='15000'
label='2004-02-15-0600'
drawGraph(tim,label)
tim='15100'
label='2004-02-15-0700'
drawGraph(tim,label)
tim='15200'
label='2004-02-15-0800'
drawGraph(tim,label)
tim='15300'
label='2004-02-15-0900'
drawGraph(tim,label)
tim='15400'
label='2004-02-15-1000'
drawGraph(tim,label)
tim='15500'
label='2004-02-15-1100'
drawGraph(tim,label)
tim='15600'
label='2004-02-15-1200'
drawGraph(tim,label)
tim='15700'
label='2004-02-15-1300'
drawGraph(tim,label)
tim='15800'
label='2004-02-15-1400'
drawGraph(tim,label)
tim='15900'
label='2004-02-15-1500'
drawGraph(tim,label)
tim='16000'
label='2004-02-15-1600'
drawGraph(tim,label)
tim='16100'
label='2004-02-15-1700'
drawGraph(tim,label)
tim='16200'
label='2004-02-15-1800'
drawGraph(tim,label)
tim='16300'
label='2004-02-15-1900'
drawGraph(tim,label)
tim='16400'
label='2004-02-15-2000'
drawGraph(tim,label)
tim='16500'
label='2004-02-15-2100'
drawGraph(tim,label)
tim='16600'
label='2004-02-15-2200'
drawGraph(tim,label)
tim='16700'
label='2004-02-15-2300'
drawGraph(tim,label)

#print surftemp
#print utcitemp
#print daysAndTimes
fig = plt.figure()
fig.set_dpi(100)
fig.set_size_inches(15.36, 9.00)


plt.title("PrestonBase8 observations vs. VTUF - " + label)
plt.ylabel("temp C")
plt.grid(True)
#plt.show()
plt.savefig('Comparison' + tim + '_' + label + '.png')
plt.close()



daysAndTimes=[]

tim='16800'
label='2004-02-16-0000'
drawGraph(tim,label)
tim='16900'
label='2004-02-16-0100'
drawGraph(tim,label)
tim='17000'
label='2004-02-16-0200'
drawGraph(tim,label)
tim='17100'
label='2004-02-16-0300'
drawGraph(tim,label)
tim='17200'
label='2004-02-16-0400'
drawGraph(tim,label)
tim='17300'
label='2004-02-16-0500'
drawGraph(tim,label)
tim='17400'
label='2004-02-16-0600'
drawGraph(tim,label)
tim='17500'
label='2004-02-16-0700'
drawGraph(tim,label)
tim='17600'
label='2004-02-16-0800'
drawGraph(tim,label)
tim='17700'
label='2004-02-16-0900'
drawGraph(tim,label)
tim='17800'
label='2004-02-16-1000'
drawGraph(tim,label)
tim='17900'
label='2004-02-16-1100'
drawGraph(tim,label)
tim='18000'
label='2004-02-16-1200'
drawGraph(tim,label)
tim='18100'
label='2004-02-16-1300'
drawGraph(tim,label)
tim='18200'
label='2004-02-16-1400'
drawGraph(tim,label)
tim='18300'
label='2004-02-16-1500'
drawGraph(tim,label)
tim='18400'
label='2004-02-16-1600'
drawGraph(tim,label)
tim='18500'
label='2004-02-16-1700'
drawGraph(tim,label)
tim='18600'
label='2004-02-16-1800'
drawGraph(tim,label)
tim='18700'
label='2004-02-16-1900'
drawGraph(tim,label)
tim='18800'
label='2004-02-16-2000'
drawGraph(tim,label)
tim='18900'
label='2004-02-16-2100'
drawGraph(tim,label)
tim='19000'
label='2004-02-16-2200'
drawGraph(tim,label)
tim='19100'
label='2004-02-16-2300'
drawGraph(tim,label)

#print surftemp
#print utcitemp
#print daysAndTimes
fig = plt.figure()
fig.set_dpi(100)
fig.set_size_inches(15.36, 9.00)


plt.title("PrestonBase8 observations vs. VTUF - " + label)
plt.ylabel("temp C")
plt.grid(True)
#plt.show()
plt.savefig('Comparison' + tim + '_' + label + '.png')
plt.close()



daysAndTimes=[]

tim='19200'
label='2004-02-17-0000'
drawGraph(tim,label)
tim='19300'
label='2004-02-17-0100'
drawGraph(tim,label)
tim='19400'
label='2004-02-17-0200'
drawGraph(tim,label)
tim='19500'
label='2004-02-17-0300'
drawGraph(tim,label)
tim='19600'
label='2004-02-17-0400'
drawGraph(tim,label)
tim='19700'
label='2004-02-17-0500'
drawGraph(tim,label)
tim='19800'
label='2004-02-17-0600'
drawGraph(tim,label)
tim='19900'
label='2004-02-17-0700'
drawGraph(tim,label)
tim='20000'
label='2004-02-17-0800'
drawGraph(tim,label)
tim='20100'
label='2004-02-17-0900'
drawGraph(tim,label)
tim='20200'
label='2004-02-17-1000'
drawGraph(tim,label)
tim='20300'
label='2004-02-17-1100'
drawGraph(tim,label)
tim='20400'
label='2004-02-17-1200'
drawGraph(tim,label)
tim='20500'
label='2004-02-17-1300'
drawGraph(tim,label)
tim='20600'
label='2004-02-17-1400'
drawGraph(tim,label)
tim='20700'
label='2004-02-17-1500'
drawGraph(tim,label)
tim='20800'
label='2004-02-17-1600'
drawGraph(tim,label)
tim='20900'
label='2004-02-17-1700'
drawGraph(tim,label)
tim='21000'
label='2004-02-17-1800'
drawGraph(tim,label)
tim='21100'
label='2004-02-17-1900'
drawGraph(tim,label)
tim='21200'
label='2004-02-17-2000'
drawGraph(tim,label)
tim='21300'
label='2004-02-17-2100'
drawGraph(tim,label)
tim='21400'
label='2004-02-17-2200'
drawGraph(tim,label)
tim='21500'
label='2004-02-17-2300'
drawGraph(tim,label)

#print surftemp
#print utcitemp
#print daysAndTimes
fig = plt.figure()
fig.set_dpi(100)
fig.set_size_inches(15.36, 9.00)


plt.title("PrestonBase8 observations vs. VTUF - " + label)
plt.ylabel("temp C")
plt.grid(True)
#plt.show()
plt.savefig('Comparison' + tim + '_' + label + '.png')
plt.close()



daysAndTimes=[]

tim='21600'
label='2004-02-18-0000'
drawGraph(tim,label)
tim='21700'
label='2004-02-18-0100'
drawGraph(tim,label)
tim='21800'
label='2004-02-18-0200'
drawGraph(tim,label)
tim='21900'
label='2004-02-18-0300'
drawGraph(tim,label)
tim='22000'
label='2004-02-18-0400'
drawGraph(tim,label)
tim='22100'
label='2004-02-18-0500'
drawGraph(tim,label)
tim='22200'
label='2004-02-18-0600'
drawGraph(tim,label)
tim='22300'
label='2004-02-18-0700'
drawGraph(tim,label)
tim='22400'
label='2004-02-18-0800'
drawGraph(tim,label)
tim='22500'
label='2004-02-18-0900'
drawGraph(tim,label)
tim='22600'
label='2004-02-18-1000'
drawGraph(tim,label)
tim='22700'
label='2004-02-18-1100'
drawGraph(tim,label)
tim='22800'
label='2004-02-18-1200'
drawGraph(tim,label)
tim='22900'
label='2004-02-18-1300'
drawGraph(tim,label)
tim='23000'
label='2004-02-18-1400'
drawGraph(tim,label)
tim='23100'
label='2004-02-18-1500'
drawGraph(tim,label)
tim='23200'
label='2004-02-18-1600'
drawGraph(tim,label)
tim='23300'
label='2004-02-18-1700'
drawGraph(tim,label)
tim='23400'
label='2004-02-18-1800'
drawGraph(tim,label)
tim='23500'
label='2004-02-18-1900'
drawGraph(tim,label)
tim='23600'
label='2004-02-18-2000'
drawGraph(tim,label)
tim='23700'
label='2004-02-18-2100'
drawGraph(tim,label)
tim='23800'
label='2004-02-18-2200'
drawGraph(tim,label)
tim='23900'
label='2004-02-18-2300'
drawGraph(tim,label)

#print surftemp
#print utcitemp
#print daysAndTimes
fig = plt.figure()
fig.set_dpi(100)
fig.set_size_inches(15.36, 9.00)


plt.title("PrestonBase8 observations vs. VTUF - " + label)
plt.ylabel("temp C")
plt.grid(True)
#plt.show()
plt.savefig('Comparison' + tim + '_' + label + '.png')
plt.close()



daysAndTimes=[]

tim='24000'
label='2004-02-19-0000'
drawGraph(tim,label)
tim='24100'
label='2004-02-19-0100'
drawGraph(tim,label)
tim='24200'
label='2004-02-19-0200'
drawGraph(tim,label)
tim='24300'
label='2004-02-19-0300'
drawGraph(tim,label)
tim='24400'
label='2004-02-19-0400'
drawGraph(tim,label)
tim='24500'
label='2004-02-19-0500'
drawGraph(tim,label)
tim='24600'
label='2004-02-19-0600'
drawGraph(tim,label)
tim='24700'
label='2004-02-19-0700'
drawGraph(tim,label)
tim='24800'
label='2004-02-19-0800'
drawGraph(tim,label)
tim='24900'
label='2004-02-19-0900'
drawGraph(tim,label)
tim='25000'
label='2004-02-19-1000'
drawGraph(tim,label)
tim='25100'
label='2004-02-19-1100'
drawGraph(tim,label)
tim='25200'
label='2004-02-19-1200'
drawGraph(tim,label)
tim='25300'
label='2004-02-19-1300'
drawGraph(tim,label)
tim='25400'
label='2004-02-19-1400'
drawGraph(tim,label)
tim='25500'
label='2004-02-19-1500'
drawGraph(tim,label)
tim='25600'
label='2004-02-19-1600'
drawGraph(tim,label)
tim='25700'
label='2004-02-19-1700'
drawGraph(tim,label)
tim='25800'
label='2004-02-19-1800'
drawGraph(tim,label)
tim='25900'
label='2004-02-19-1900'
drawGraph(tim,label)
tim='26000'
label='2004-02-19-2000'
drawGraph(tim,label)
tim='26100'
label='2004-02-19-2100'
drawGraph(tim,label)
tim='26200'
label='2004-02-19-2200'
drawGraph(tim,label)
tim='26300'
label='2004-02-19-2300'
drawGraph(tim,label)

#print surftemp
#print utcitemp
#print daysAndTimes
fig = plt.figure()
fig.set_dpi(100)
fig.set_size_inches(15.36, 9.00)


plt.title("PrestonBase8 observations vs. VTUF - " + label)
plt.ylabel("temp C")
plt.grid(True)
#plt.show()
plt.savefig('Comparison' + tim + '_' + label + '.png')
plt.close()



daysAndTimes=[]

tim='26400'
label='2004-02-20-0000'
drawGraph(tim,label)
tim='26500'
label='2004-02-20-0100'
drawGraph(tim,label)
tim='26600'
label='2004-02-20-0200'
drawGraph(tim,label)
tim='26700'
label='2004-02-20-0300'
drawGraph(tim,label)
tim='26800'
label='2004-02-20-0400'
drawGraph(tim,label)
tim='26900'
label='2004-02-20-0500'
drawGraph(tim,label)
tim='27000'
label='2004-02-20-0600'
drawGraph(tim,label)
tim='27100'
label='2004-02-20-0700'
drawGraph(tim,label)
tim='27200'
label='2004-02-20-0800'
drawGraph(tim,label)
tim='27300'
label='2004-02-20-0900'
drawGraph(tim,label)
tim='27400'
label='2004-02-20-1000'
drawGraph(tim,label)
tim='27500'
label='2004-02-20-1100'
drawGraph(tim,label)
tim='27600'
label='2004-02-20-1200'
drawGraph(tim,label)
tim='27700'
label='2004-02-20-1300'
drawGraph(tim,label)
tim='27800'
label='2004-02-20-1400'
drawGraph(tim,label)
tim='27900'
label='2004-02-20-1500'
drawGraph(tim,label)
tim='28000'
label='2004-02-20-1600'
drawGraph(tim,label)
tim='28100'
label='2004-02-20-1700'
drawGraph(tim,label)
tim='28200'
label='2004-02-20-1800'
drawGraph(tim,label)
tim='28300'
label='2004-02-20-1900'
drawGraph(tim,label)
tim='28400'
label='2004-02-20-2000'
drawGraph(tim,label)
tim='28500'
label='2004-02-20-2100'
drawGraph(tim,label)
tim='28600'
label='2004-02-20-2200'
drawGraph(tim,label)
tim='28700'
label='2004-02-20-2300'
drawGraph(tim,label)

#print surftemp
#print utcitemp
#print daysAndTimes
fig = plt.figure()
fig.set_dpi(100)
fig.set_size_inches(15.36, 9.00)


plt.title("PrestonBase8 observations vs. VTUF - " + label)
plt.ylabel("temp C")
plt.grid(True)
#plt.show()
plt.savefig('Comparison' + tim + '_' + label + '.png')
plt.close()



daysAndTimes=[]

tim='28800'
label='2004-02-21-0000'
drawGraph(tim,label)
tim='28900'
label='2004-02-21-0100'
drawGraph(tim,label)
tim='29000'
label='2004-02-21-0200'
drawGraph(tim,label)
tim='29100'
label='2004-02-21-0300'
drawGraph(tim,label)
tim='29200'
label='2004-02-21-0400'
drawGraph(tim,label)
tim='29300'
label='2004-02-21-0500'
drawGraph(tim,label)
tim='29400'
label='2004-02-21-0600'
drawGraph(tim,label)
tim='29500'
label='2004-02-21-0700'
drawGraph(tim,label)
tim='29600'
label='2004-02-21-0800'
drawGraph(tim,label)
tim='29700'
label='2004-02-21-0900'
drawGraph(tim,label)
tim='29800'
label='2004-02-21-1000'
drawGraph(tim,label)
tim='29900'
label='2004-02-21-1100'
drawGraph(tim,label)
tim='30000'
label='2004-02-21-1200'
drawGraph(tim,label)
tim='30100'
label='2004-02-21-1300'
drawGraph(tim,label)
tim='30200'
label='2004-02-21-1400'
drawGraph(tim,label)
tim='30300'
label='2004-02-21-1500'
drawGraph(tim,label)
tim='30400'
label='2004-02-21-1600'
drawGraph(tim,label)
tim='30500'
label='2004-02-21-1700'
drawGraph(tim,label)
tim='30600'
label='2004-02-21-1800'
drawGraph(tim,label)
tim='30700'
label='2004-02-21-1900'
drawGraph(tim,label)
tim='30800'
label='2004-02-21-2000'
drawGraph(tim,label)
tim='30900'
label='2004-02-21-2100'
drawGraph(tim,label)
tim='31000'
label='2004-02-21-2200'
drawGraph(tim,label)
tim='31100'
label='2004-02-21-2300'
drawGraph(tim,label)

#print surftemp
#print utcitemp
#print daysAndTimes
fig = plt.figure()
fig.set_dpi(100)
fig.set_size_inches(15.36, 9.00)


plt.title("PrestonBase8 observations vs. VTUF - " + label)
plt.ylabel("temp C")
plt.grid(True)
#plt.show()
plt.savefig('Comparison' + tim + '_' + label + '.png')
plt.close()



daysAndTimes=[]

tim='31200'
label='2004-02-22-0000'
drawGraph(tim,label)
tim='31300'
label='2004-02-22-0100'
drawGraph(tim,label)
tim='31400'
label='2004-02-22-0200'
drawGraph(tim,label)
tim='31500'
label='2004-02-22-0300'
drawGraph(tim,label)
tim='31600'
label='2004-02-22-0400'
drawGraph(tim,label)
tim='31700'
label='2004-02-22-0500'
drawGraph(tim,label)
tim='31800'
label='2004-02-22-0600'
drawGraph(tim,label)
tim='31900'
label='2004-02-22-0700'
drawGraph(tim,label)
tim='32000'
label='2004-02-22-0800'
drawGraph(tim,label)
tim='32100'
label='2004-02-22-0900'
drawGraph(tim,label)
tim='32200'
label='2004-02-22-1000'
drawGraph(tim,label)
tim='32300'
label='2004-02-22-1100'
drawGraph(tim,label)
tim='32400'
label='2004-02-22-1200'
drawGraph(tim,label)
tim='32500'
label='2004-02-22-1300'
drawGraph(tim,label)
tim='32600'
label='2004-02-22-1400'
drawGraph(tim,label)
tim='32700'
label='2004-02-22-1500'
drawGraph(tim,label)
tim='32800'
label='2004-02-22-1600'
drawGraph(tim,label)
tim='32900'
label='2004-02-22-1700'
drawGraph(tim,label)
tim='33000'
label='2004-02-22-1800'
drawGraph(tim,label)
tim='33100'
label='2004-02-22-1900'
drawGraph(tim,label)
tim='33200'
label='2004-02-22-2000'
drawGraph(tim,label)
tim='33300'
label='2004-02-22-2100'
drawGraph(tim,label)
tim='33400'
label='2004-02-22-2200'
drawGraph(tim,label)
tim='33500'
label='2004-02-22-2300'
drawGraph(tim,label)

#print surftemp
#print utcitemp
#print daysAndTimes
fig = plt.figure()
fig.set_dpi(100)
fig.set_size_inches(15.36, 9.00)


plt.title("PrestonBase8 observations vs. VTUF - " + label)
plt.ylabel("temp C")
plt.grid(True)
#plt.show()
plt.savefig('Comparison' + tim + '_' + label + '.png')
plt.close()



daysAndTimes=[]

tim='33600'
label='2004-02-23-0000'
drawGraph(tim,label)
tim='33700'
label='2004-02-23-0100'
drawGraph(tim,label)
tim='33800'
label='2004-02-23-0200'
drawGraph(tim,label)
tim='33900'
label='2004-02-23-0300'
drawGraph(tim,label)
tim='34000'
label='2004-02-23-0400'
drawGraph(tim,label)
tim='34100'
label='2004-02-23-0500'
drawGraph(tim,label)
tim='34200'
label='2004-02-23-0600'
drawGraph(tim,label)
tim='34300'
label='2004-02-23-0700'
drawGraph(tim,label)
tim='34400'
label='2004-02-23-0800'
drawGraph(tim,label)
tim='34500'
label='2004-02-23-0900'
drawGraph(tim,label)
tim='34600'
label='2004-02-23-1000'
drawGraph(tim,label)
tim='34700'
label='2004-02-23-1100'
drawGraph(tim,label)
tim='34800'
label='2004-02-23-1200'
drawGraph(tim,label)
tim='34900'
label='2004-02-23-1300'
drawGraph(tim,label)
tim='35000'
label='2004-02-23-1400'
drawGraph(tim,label)
tim='35100'
label='2004-02-23-1500'
drawGraph(tim,label)
tim='35200'
label='2004-02-23-1600'
drawGraph(tim,label)
tim='35300'
label='2004-02-23-1700'
drawGraph(tim,label)
tim='35400'
label='2004-02-23-1800'
drawGraph(tim,label)
tim='35500'
label='2004-02-23-1900'
drawGraph(tim,label)
tim='35600'
label='2004-02-23-2000'
drawGraph(tim,label)
tim='35700'
label='2004-02-23-2100'
drawGraph(tim,label)
tim='35800'
label='2004-02-23-2200'
drawGraph(tim,label)
tim='35900'
label='2004-02-23-2300'
drawGraph(tim,label)

#print surftemp
#print utcitemp
#print daysAndTimes
fig = plt.figure()
fig.set_dpi(100)
fig.set_size_inches(15.36, 9.00)


plt.title("PrestonBase8 observations vs. VTUF - " + label)
plt.ylabel("temp C")
plt.grid(True)
#plt.show()
plt.savefig('Comparison' + tim + '_' + label + '.png')
plt.close()



daysAndTimes=[]

tim='36000'
label='2004-02-24-0000'
drawGraph(tim,label)
tim='36100'
label='2004-02-24-0100'
drawGraph(tim,label)
tim='36200'
label='2004-02-24-0200'
drawGraph(tim,label)
tim='36300'
label='2004-02-24-0300'
drawGraph(tim,label)
tim='36400'
label='2004-02-24-0400'
drawGraph(tim,label)
tim='36500'
label='2004-02-24-0500'
drawGraph(tim,label)
tim='36600'
label='2004-02-24-0600'
drawGraph(tim,label)
tim='36700'
label='2004-02-24-0700'
drawGraph(tim,label)
tim='36800'
label='2004-02-24-0800'
drawGraph(tim,label)
tim='36900'
label='2004-02-24-0900'
drawGraph(tim,label)
tim='37000'
label='2004-02-24-1000'
drawGraph(tim,label)
tim='37100'
label='2004-02-24-1100'
drawGraph(tim,label)
tim='37200'
label='2004-02-24-1200'
drawGraph(tim,label)
tim='37300'
label='2004-02-24-1300'
drawGraph(tim,label)
tim='37400'
label='2004-02-24-1400'
drawGraph(tim,label)
tim='37500'
label='2004-02-24-1500'
drawGraph(tim,label)
tim='37600'
label='2004-02-24-1600'
drawGraph(tim,label)
tim='37700'
label='2004-02-24-1700'
drawGraph(tim,label)
tim='37800'
label='2004-02-24-1800'
drawGraph(tim,label)
tim='37900'
label='2004-02-24-1900'
drawGraph(tim,label)
tim='38000'
label='2004-02-24-2000'
drawGraph(tim,label)
tim='38100'
label='2004-02-24-2100'
drawGraph(tim,label)
tim='38200'
label='2004-02-24-2200'
drawGraph(tim,label)
tim='38300'
label='2004-02-24-2300'
drawGraph(tim,label)

#print surftemp
#print utcitemp
#print daysAndTimes
fig = plt.figure()
fig.set_dpi(100)
fig.set_size_inches(15.36, 9.00)


plt.title("PrestonBase8 observations vs. VTUF - " + label)
plt.ylabel("temp C")
plt.grid(True)
#plt.show()
plt.savefig('Comparison' + tim + '_' + label + '.png')
plt.close()



daysAndTimes=[]

tim='38400'
label='2004-02-25-0000'
drawGraph(tim,label)
tim='38500'
label='2004-02-25-0100'
drawGraph(tim,label)
tim='38600'
label='2004-02-25-0200'
drawGraph(tim,label)
tim='38700'
label='2004-02-25-0300'
drawGraph(tim,label)
tim='38800'
label='2004-02-25-0400'
drawGraph(tim,label)
tim='38900'
label='2004-02-25-0500'
drawGraph(tim,label)
tim='39000'
label='2004-02-25-0600'
drawGraph(tim,label)
tim='39100'
label='2004-02-25-0700'
drawGraph(tim,label)
tim='39200'
label='2004-02-25-0800'
drawGraph(tim,label)
tim='39300'
label='2004-02-25-0900'
drawGraph(tim,label)
tim='39400'
label='2004-02-25-1000'
drawGraph(tim,label)
tim='39500'
label='2004-02-25-1100'
drawGraph(tim,label)
tim='39600'
label='2004-02-25-1200'
drawGraph(tim,label)
tim='39700'
label='2004-02-25-1300'
drawGraph(tim,label)
tim='39800'
label='2004-02-25-1400'
drawGraph(tim,label)
tim='39900'
label='2004-02-25-1500'
drawGraph(tim,label)
tim='40000'
label='2004-02-25-1600'
drawGraph(tim,label)
tim='40100'
label='2004-02-25-1700'
drawGraph(tim,label)
tim='40200'
label='2004-02-25-1800'
drawGraph(tim,label)
tim='40300'
label='2004-02-25-1900'
drawGraph(tim,label)
tim='40400'
label='2004-02-25-2000'
drawGraph(tim,label)
tim='40500'
label='2004-02-25-2100'
drawGraph(tim,label)
tim='40600'
label='2004-02-25-2200'
drawGraph(tim,label)
tim='40700'
label='2004-02-25-2300'
drawGraph(tim,label)

#print surftemp
#print utcitemp
#print daysAndTimes
fig = plt.figure()
fig.set_dpi(100)
fig.set_size_inches(15.36, 9.00)


plt.title("PrestonBase8 observations vs. VTUF - " + label)
plt.ylabel("temp C")
plt.grid(True)
#plt.show()
plt.savefig('Comparison' + tim + '_' + label + '.png')
plt.close()



daysAndTimes=[]

tim='40800'
label='2004-02-26-0000'
drawGraph(tim,label)
tim='40900'
label='2004-02-26-0100'
drawGraph(tim,label)
tim='41000'
label='2004-02-26-0200'
drawGraph(tim,label)
tim='41100'
label='2004-02-26-0300'
drawGraph(tim,label)
tim='41200'
label='2004-02-26-0400'
drawGraph(tim,label)
tim='41300'
label='2004-02-26-0500'
drawGraph(tim,label)
tim='41400'
label='2004-02-26-0600'
drawGraph(tim,label)
tim='41500'
label='2004-02-26-0700'
drawGraph(tim,label)
tim='41600'
label='2004-02-26-0800'
drawGraph(tim,label)
tim='41700'
label='2004-02-26-0900'
drawGraph(tim,label)
tim='41800'
label='2004-02-26-1000'
drawGraph(tim,label)
tim='41900'
label='2004-02-26-1100'
drawGraph(tim,label)
tim='42000'
label='2004-02-26-1200'
drawGraph(tim,label)
tim='42100'
label='2004-02-26-1300'
drawGraph(tim,label)
tim='42200'
label='2004-02-26-1400'
drawGraph(tim,label)
tim='42300'
label='2004-02-26-1500'
drawGraph(tim,label)
tim='42400'
label='2004-02-26-1600'
drawGraph(tim,label)
tim='42500'
label='2004-02-26-1700'
drawGraph(tim,label)
tim='42600'
label='2004-02-26-1800'
drawGraph(tim,label)
tim='42700'
label='2004-02-26-1900'
drawGraph(tim,label)
tim='42800'
label='2004-02-26-2000'
drawGraph(tim,label)
tim='42900'
label='2004-02-26-2100'
drawGraph(tim,label)
tim='43000'
label='2004-02-26-2200'
drawGraph(tim,label)
tim='43100'
label='2004-02-26-2300'
drawGraph(tim,label)

#print surftemp
#print utcitemp
#print daysAndTimes
fig = plt.figure()
fig.set_dpi(100)
fig.set_size_inches(15.36, 9.00)


plt.title("PrestonBase8 observations vs. VTUF - " + label)
plt.ylabel("temp C")
plt.grid(True)
#plt.show()
plt.savefig('Comparison' + tim + '_' + label + '.png')
plt.close()



daysAndTimes=[]

tim='43200'
label='2004-02-27-0000'
drawGraph(tim,label)
tim='43300'
label='2004-02-27-0100'
drawGraph(tim,label)
tim='43400'
label='2004-02-27-0200'
drawGraph(tim,label)
tim='43500'
label='2004-02-27-0300'
drawGraph(tim,label)
tim='43600'
label='2004-02-27-0400'
drawGraph(tim,label)
tim='43700'
label='2004-02-27-0500'
drawGraph(tim,label)
tim='43800'
label='2004-02-27-0600'
drawGraph(tim,label)
tim='43900'
label='2004-02-27-0700'
drawGraph(tim,label)
tim='44000'
label='2004-02-27-0800'
drawGraph(tim,label)
tim='44100'
label='2004-02-27-0900'
drawGraph(tim,label)
tim='44200'
label='2004-02-27-1000'
drawGraph(tim,label)
tim='44300'
label='2004-02-27-1100'
drawGraph(tim,label)
tim='44400'
label='2004-02-27-1200'
drawGraph(tim,label)
tim='44500'
label='2004-02-27-1300'
drawGraph(tim,label)
tim='44600'
label='2004-02-27-1400'
drawGraph(tim,label)
tim='44700'
label='2004-02-27-1500'
drawGraph(tim,label)
tim='44800'
label='2004-02-27-1600'
drawGraph(tim,label)
tim='44900'
label='2004-02-27-1700'
drawGraph(tim,label)
tim='45000'
label='2004-02-27-1800'
drawGraph(tim,label)
tim='45100'
label='2004-02-27-1900'
drawGraph(tim,label)
tim='45200'
label='2004-02-27-2000'
drawGraph(tim,label)
tim='45300'
label='2004-02-27-2100'
drawGraph(tim,label)
tim='45400'
label='2004-02-27-2200'
drawGraph(tim,label)
tim='45500'
label='2004-02-27-2300'
drawGraph(tim,label)

#print surftemp
#print utcitemp
#print daysAndTimes
fig = plt.figure()
fig.set_dpi(100)
fig.set_size_inches(15.36, 9.00)


plt.title("PrestonBase8 observations vs. VTUF - " + label)
plt.ylabel("temp C")
plt.grid(True)
#plt.show()
plt.savefig('Comparison' + tim + '_' + label + '.png')
plt.close()



daysAndTimes=[]

tim='45600'
label='2004-02-28-0000'
drawGraph(tim,label)
tim='45700'
label='2004-02-28-0100'
drawGraph(tim,label)
tim='45800'
label='2004-02-28-0200'
drawGraph(tim,label)
tim='45900'
label='2004-02-28-0300'
drawGraph(tim,label)
tim='46000'
label='2004-02-28-0400'
drawGraph(tim,label)
tim='46100'
label='2004-02-28-0500'
drawGraph(tim,label)
tim='46200'
label='2004-02-28-0600'
drawGraph(tim,label)
tim='46300'
label='2004-02-28-0700'
drawGraph(tim,label)
tim='46400'
label='2004-02-28-0800'
drawGraph(tim,label)
tim='46500'
label='2004-02-28-0900'
drawGraph(tim,label)
tim='46600'
label='2004-02-28-1000'
drawGraph(tim,label)
tim='46700'
label='2004-02-28-1100'
drawGraph(tim,label)
tim='46800'
label='2004-02-28-1200'
drawGraph(tim,label)
tim='46900'
label='2004-02-28-1300'
drawGraph(tim,label)
tim='47000'
label='2004-02-28-1400'
drawGraph(tim,label)
tim='47100'
label='2004-02-28-1500'
drawGraph(tim,label)
tim='47200'
label='2004-02-28-1600'
drawGraph(tim,label)
tim='47300'
label='2004-02-28-1700'
drawGraph(tim,label)
tim='47400'
label='2004-02-28-1800'
drawGraph(tim,label)
tim='47500'
label='2004-02-28-1900'
drawGraph(tim,label)
tim='47600'
label='2004-02-28-2000'
drawGraph(tim,label)
tim='47700'
label='2004-02-28-2100'
drawGraph(tim,label)
tim='47800'
label='2004-02-28-2200'
drawGraph(tim,label)
tim='47900'
label='2004-02-28-2300'
drawGraph(tim,label)

#print surftemp
#print utcitemp
#print daysAndTimes
fig = plt.figure()
fig.set_dpi(100)
fig.set_size_inches(15.36, 9.00)


plt.title("PrestonBase8 observations vs. VTUF - " + label)
plt.ylabel("temp C")
plt.grid(True)
#plt.show()
plt.savefig('Comparison' + tim + '_' + label + '.png')
plt.close()



daysAndTimes=[]

tim='48000'
label='2004-02-29-0000'
drawGraph(tim,label)
tim='48100'
label='2004-02-29-0100'
drawGraph(tim,label)
tim='48200'
label='2004-02-29-0200'
drawGraph(tim,label)
tim='48300'
label='2004-02-29-0300'
drawGraph(tim,label)
tim='48400'
label='2004-02-29-0400'
drawGraph(tim,label)
tim='48500'
label='2004-02-29-0500'
drawGraph(tim,label)
tim='48600'
label='2004-02-29-0600'
drawGraph(tim,label)
tim='48700'
label='2004-02-29-0700'
drawGraph(tim,label)
tim='48800'
label='2004-02-29-0800'
drawGraph(tim,label)
tim='48900'
label='2004-02-29-0900'
drawGraph(tim,label)
tim='49000'
label='2004-02-29-1000'
drawGraph(tim,label)
tim='49100'
label='2004-02-29-1100'
drawGraph(tim,label)
tim='49200'
label='2004-02-29-1200'
drawGraph(tim,label)
tim='49300'
label='2004-02-29-1300'
drawGraph(tim,label)
tim='49400'
label='2004-02-29-1400'
drawGraph(tim,label)
tim='49500'
label='2004-02-29-1500'
drawGraph(tim,label)
tim='49600'
label='2004-02-29-1600'
drawGraph(tim,label)
tim='49700'
label='2004-02-29-1700'
drawGraph(tim,label)
tim='49800'
label='2004-02-29-1800'
drawGraph(tim,label)
tim='49900'
label='2004-02-29-1900'
drawGraph(tim,label)
tim='50000'
label='2004-02-29-2000'
drawGraph(tim,label)
tim='50100'
label='2004-02-29-2100'
drawGraph(tim,label)
tim='50200'
label='2004-02-29-2200'
drawGraph(tim,label)
tim='50300'
label='2004-02-29-2300'
drawGraph(tim,label)

#print surftemp
#print utcitemp
#print daysAndTimes
fig = plt.figure()
fig.set_dpi(100)
fig.set_size_inches(15.36, 9.00)


plt.title("PrestonBase8 observations vs. VTUF - " + label)
plt.ylabel("temp C")
plt.grid(True)
#plt.show()
plt.savefig('Comparison' + tim + '_' + label + '.png')
plt.close()



daysAndTimes=[]

tim='50400'
label='2004-03-01-0000'
drawGraph(tim,label)
tim='50500'
label='2004-03-01-0100'
drawGraph(tim,label)
tim='50600'
label='2004-03-01-0200'
drawGraph(tim,label)
tim='50700'
label='2004-03-01-0300'
drawGraph(tim,label)
tim='50800'
label='2004-03-01-0400'
drawGraph(tim,label)
tim='50900'
label='2004-03-01-0500'
drawGraph(tim,label)
tim='51000'
label='2004-03-01-0600'
drawGraph(tim,label)
tim='51100'
label='2004-03-01-0700'
drawGraph(tim,label)
tim='51200'
label='2004-03-01-0800'
drawGraph(tim,label)
tim='51300'
label='2004-03-01-0900'
drawGraph(tim,label)
tim='51400'
label='2004-03-01-1000'
drawGraph(tim,label)
tim='51500'
label='2004-03-01-1100'
drawGraph(tim,label)
tim='51600'
label='2004-03-01-1200'
drawGraph(tim,label)
tim='51700'
label='2004-03-01-1300'
drawGraph(tim,label)
tim='51800'
label='2004-03-01-1400'
drawGraph(tim,label)
tim='51900'
label='2004-03-01-1500'
drawGraph(tim,label)
tim='52000'
label='2004-03-01-1600'
drawGraph(tim,label)
tim='52100'
label='2004-03-01-1700'
drawGraph(tim,label)
tim='52200'
label='2004-03-01-1800'
drawGraph(tim,label)
tim='52300'
label='2004-03-01-1900'
drawGraph(tim,label)
tim='52400'
label='2004-03-01-2000'
drawGraph(tim,label)
tim='52500'
label='2004-03-01-2100'
drawGraph(tim,label)
tim='52600'
label='2004-03-01-2200'
drawGraph(tim,label)
tim='52700'
label='2004-03-01-2300'
drawGraph(tim,label)

#print surftemp
#print utcitemp
#print daysAndTimes
fig = plt.figure()
fig.set_dpi(100)
fig.set_size_inches(15.36, 9.00)


plt.title("PrestonBase8 observations vs. VTUF - " + label)
plt.ylabel("temp C")
plt.grid(True)
#plt.show()
plt.savefig('Comparison' + tim + '_' + label + '.png')
plt.close()



daysAndTimes=[]

tim='52800'
label='2004-03-02-0000'
drawGraph(tim,label)
tim='52900'
label='2004-03-02-0100'
drawGraph(tim,label)
tim='53000'
label='2004-03-02-0200'
drawGraph(tim,label)
tim='53100'
label='2004-03-02-0300'
drawGraph(tim,label)
tim='53200'
label='2004-03-02-0400'
drawGraph(tim,label)
tim='53300'
label='2004-03-02-0500'
drawGraph(tim,label)
tim='53400'
label='2004-03-02-0600'
drawGraph(tim,label)
tim='53500'
label='2004-03-02-0700'
drawGraph(tim,label)
tim='53600'
label='2004-03-02-0800'
drawGraph(tim,label)
tim='53700'
label='2004-03-02-0900'
drawGraph(tim,label)
tim='53800'
label='2004-03-02-1000'
drawGraph(tim,label)
tim='53900'
label='2004-03-02-1100'
drawGraph(tim,label)
tim='54000'
label='2004-03-02-1200'
drawGraph(tim,label)
tim='54100'
label='2004-03-02-1300'
drawGraph(tim,label)
tim='54200'
label='2004-03-02-1400'
drawGraph(tim,label)
tim='54300'
label='2004-03-02-1500'
drawGraph(tim,label)
tim='54400'
label='2004-03-02-1600'
drawGraph(tim,label)
tim='54500'
label='2004-03-02-1700'
drawGraph(tim,label)
tim='54600'
label='2004-03-02-1800'
drawGraph(tim,label)
tim='54700'
label='2004-03-02-1900'
drawGraph(tim,label)
tim='54800'
label='2004-03-02-2000'
drawGraph(tim,label)
tim='54900'
label='2004-03-02-2100'
drawGraph(tim,label)
tim='55000'
label='2004-03-02-2200'
drawGraph(tim,label)
tim='55100'
label='2004-03-02-2300'
drawGraph(tim,label)

#print surftemp
#print utcitemp
#print daysAndTimes
fig = plt.figure()
fig.set_dpi(100)
fig.set_size_inches(15.36, 9.00)


plt.title("PrestonBase8 observations vs. VTUF - " + label)
plt.ylabel("temp C")
plt.grid(True)
#plt.show()
plt.savefig('Comparison' + tim + '_' + label + '.png')
plt.close()



daysAndTimes=[]

tim='55200'
label='2004-03-03-0000'
drawGraph(tim,label)
tim='55300'
label='2004-03-03-0100'
drawGraph(tim,label)
tim='55400'
label='2004-03-03-0200'
drawGraph(tim,label)
tim='55500'
label='2004-03-03-0300'
drawGraph(tim,label)
tim='55600'
label='2004-03-03-0400'
drawGraph(tim,label)
tim='55700'
label='2004-03-03-0500'
drawGraph(tim,label)
tim='55800'
label='2004-03-03-0600'
drawGraph(tim,label)
tim='55900'
label='2004-03-03-0700'
drawGraph(tim,label)
tim='56000'
label='2004-03-03-0800'
drawGraph(tim,label)
tim='56100'
label='2004-03-03-0900'
drawGraph(tim,label)
tim='56200'
label='2004-03-03-1000'
drawGraph(tim,label)
tim='56300'
label='2004-03-03-1100'
drawGraph(tim,label)
tim='56400'
label='2004-03-03-1200'
drawGraph(tim,label)
tim='56500'
label='2004-03-03-1300'
drawGraph(tim,label)
tim='56600'
label='2004-03-03-1400'
drawGraph(tim,label)
tim='56700'
label='2004-03-03-1500'
drawGraph(tim,label)
tim='56800'
label='2004-03-03-1600'
drawGraph(tim,label)
tim='56900'
label='2004-03-03-1700'
drawGraph(tim,label)
tim='57000'
label='2004-03-03-1800'
drawGraph(tim,label)
tim='57100'
label='2004-03-03-1900'
drawGraph(tim,label)
tim='57200'
label='2004-03-03-2000'
drawGraph(tim,label)
tim='57300'
label='2004-03-03-2100'
drawGraph(tim,label)
tim='57400'
label='2004-03-03-2200'
drawGraph(tim,label)
tim='57500'
label='2004-03-03-2300'
drawGraph(tim,label)

#print surftemp
#print utcitemp
#print daysAndTimes
fig = plt.figure()
fig.set_dpi(100)
fig.set_size_inches(15.36, 9.00)


plt.title("PrestonBase8 observations vs. VTUF - " + label)
plt.ylabel("temp C")
plt.grid(True)
#plt.show()
plt.savefig('Comparison' + tim + '_' + label + '.png')
plt.close()



daysAndTimes=[]

tim='57600'
label='2004-03-04-0000'
drawGraph(tim,label)
tim='57700'
label='2004-03-04-0100'
drawGraph(tim,label)
tim='57800'
label='2004-03-04-0200'
drawGraph(tim,label)
tim='57900'
label='2004-03-04-0300'
drawGraph(tim,label)
tim='58000'
label='2004-03-04-0400'
drawGraph(tim,label)
tim='58100'
label='2004-03-04-0500'
drawGraph(tim,label)
tim='58200'
label='2004-03-04-0600'
drawGraph(tim,label)
tim='58300'
label='2004-03-04-0700'
drawGraph(tim,label)
tim='58400'
label='2004-03-04-0800'
drawGraph(tim,label)
tim='58500'
label='2004-03-04-0900'
drawGraph(tim,label)
tim='58600'
label='2004-03-04-1000'
drawGraph(tim,label)
tim='58700'
label='2004-03-04-1100'
drawGraph(tim,label)
tim='58800'
label='2004-03-04-1200'
drawGraph(tim,label)
tim='58900'
label='2004-03-04-1300'
drawGraph(tim,label)
tim='59000'
label='2004-03-04-1400'
drawGraph(tim,label)
tim='59100'
label='2004-03-04-1500'
drawGraph(tim,label)
tim='59200'
label='2004-03-04-1600'
drawGraph(tim,label)
tim='59300'
label='2004-03-04-1700'
drawGraph(tim,label)
tim='59400'
label='2004-03-04-1800'
drawGraph(tim,label)
tim='59500'
label='2004-03-04-1900'
drawGraph(tim,label)
tim='59600'
label='2004-03-04-2000'
drawGraph(tim,label)
tim='59700'
label='2004-03-04-2100'
drawGraph(tim,label)
tim='59800'
label='2004-03-04-2200'
drawGraph(tim,label)
tim='59900'
label='2004-03-04-2300'
drawGraph(tim,label)

#print surftemp
#print utcitemp
#print daysAndTimes
fig = plt.figure()
fig.set_dpi(100)
fig.set_size_inches(15.36, 9.00)


plt.title("PrestonBase8 observations vs. VTUF - " + label)
plt.ylabel("temp C")
plt.grid(True)
#plt.show()
plt.savefig('Comparison' + tim + '_' + label + '.png')
plt.close()



daysAndTimes=[]

tim='60000'
label='2004-03-05-0000'
drawGraph(tim,label)
tim='60100'
label='2004-03-05-0100'
drawGraph(tim,label)
tim='60200'
label='2004-03-05-0200'
drawGraph(tim,label)
tim='60300'
label='2004-03-05-0300'
drawGraph(tim,label)
tim='60400'
label='2004-03-05-0400'
drawGraph(tim,label)
tim='60500'
label='2004-03-05-0500'
drawGraph(tim,label)
tim='60600'
label='2004-03-05-0600'
drawGraph(tim,label)
tim='60700'
label='2004-03-05-0700'
drawGraph(tim,label)
tim='60800'
label='2004-03-05-0800'
drawGraph(tim,label)
tim='60900'
label='2004-03-05-0900'
drawGraph(tim,label)
tim='61000'
label='2004-03-05-1000'
drawGraph(tim,label)
tim='61100'
label='2004-03-05-1100'
drawGraph(tim,label)
tim='61200'
label='2004-03-05-1200'
drawGraph(tim,label)
tim='61300'
label='2004-03-05-1300'
drawGraph(tim,label)
tim='61400'
label='2004-03-05-1400'
drawGraph(tim,label)
tim='61500'
label='2004-03-05-1500'
drawGraph(tim,label)
tim='61600'
label='2004-03-05-1600'
drawGraph(tim,label)
tim='61700'
label='2004-03-05-1700'
drawGraph(tim,label)
tim='61800'
label='2004-03-05-1800'
drawGraph(tim,label)
tim='61900'
label='2004-03-05-1900'
drawGraph(tim,label)
tim='62000'
label='2004-03-05-2000'
drawGraph(tim,label)
tim='62100'
label='2004-03-05-2100'
drawGraph(tim,label)
tim='62200'
label='2004-03-05-2200'
drawGraph(tim,label)
tim='62300'
label='2004-03-05-2300'
drawGraph(tim,label)

#print surftemp
#print utcitemp
#print daysAndTimes
fig = plt.figure()
fig.set_dpi(100)
fig.set_size_inches(15.36, 9.00)


plt.title("PrestonBase8 observations vs. VTUF - " + label)
plt.ylabel("temp C")
plt.grid(True)
#plt.show()
plt.savefig('Comparison' + tim + '_' + label + '.png')
plt.close()



daysAndTimes=[]

tim='62400'
label='2004-03-06-0000'
drawGraph(tim,label)
tim='62500'
label='2004-03-06-0100'
drawGraph(tim,label)
tim='62600'
label='2004-03-06-0200'
drawGraph(tim,label)
tim='62700'
label='2004-03-06-0300'
drawGraph(tim,label)
tim='62800'
label='2004-03-06-0400'
drawGraph(tim,label)
tim='62900'
label='2004-03-06-0500'
drawGraph(tim,label)
tim='63000'
label='2004-03-06-0600'
drawGraph(tim,label)
tim='63100'
label='2004-03-06-0700'
drawGraph(tim,label)
tim='63200'
label='2004-03-06-0800'
drawGraph(tim,label)
tim='63300'
label='2004-03-06-0900'
drawGraph(tim,label)
tim='63400'
label='2004-03-06-1000'
drawGraph(tim,label)
tim='63500'
label='2004-03-06-1100'
drawGraph(tim,label)
tim='63600'
label='2004-03-06-1200'
drawGraph(tim,label)
tim='63700'
label='2004-03-06-1300'
drawGraph(tim,label)
tim='63800'
label='2004-03-06-1400'
drawGraph(tim,label)
tim='63900'
label='2004-03-06-1500'
drawGraph(tim,label)
tim='64000'
label='2004-03-06-1600'
drawGraph(tim,label)
tim='64100'
label='2004-03-06-1700'
drawGraph(tim,label)
tim='64200'
label='2004-03-06-1800'
drawGraph(tim,label)
tim='64300'
label='2004-03-06-1900'
drawGraph(tim,label)
tim='64400'
label='2004-03-06-2000'
drawGraph(tim,label)
tim='64500'
label='2004-03-06-2100'
drawGraph(tim,label)
tim='64600'
label='2004-03-06-2200'
drawGraph(tim,label)
tim='64700'
label='2004-03-06-2300'
drawGraph(tim,label)

#print surftemp
#print utcitemp
#print daysAndTimes
fig = plt.figure()
fig.set_dpi(100)
fig.set_size_inches(15.36, 9.00)


plt.title("PrestonBase8 observations vs. VTUF - " + label)
plt.ylabel("temp C")
plt.grid(True)
#plt.show()
plt.savefig('Comparison' + tim + '_' + label + '.png')
plt.close()



daysAndTimes=[]

tim='64800'
label='2004-03-07-0000'
drawGraph(tim,label)
tim='64900'
label='2004-03-07-0100'
drawGraph(tim,label)
tim='65000'
label='2004-03-07-0200'
drawGraph(tim,label)
tim='65100'
label='2004-03-07-0300'
drawGraph(tim,label)
tim='65200'
label='2004-03-07-0400'
drawGraph(tim,label)
tim='65300'
label='2004-03-07-0500'
drawGraph(tim,label)
tim='65400'
label='2004-03-07-0600'
drawGraph(tim,label)
tim='65500'
label='2004-03-07-0700'
drawGraph(tim,label)
tim='65600'
label='2004-03-07-0800'
drawGraph(tim,label)
tim='65700'
label='2004-03-07-0900'
drawGraph(tim,label)
tim='65800'
label='2004-03-07-1000'
drawGraph(tim,label)
tim='65900'
label='2004-03-07-1100'
drawGraph(tim,label)
tim='66000'
label='2004-03-07-1200'
drawGraph(tim,label)
tim='66100'
label='2004-03-07-1300'
drawGraph(tim,label)
tim='66200'
label='2004-03-07-1400'
drawGraph(tim,label)
tim='66300'
label='2004-03-07-1500'
drawGraph(tim,label)
tim='66400'
label='2004-03-07-1600'
drawGraph(tim,label)
tim='66500'
label='2004-03-07-1700'
drawGraph(tim,label)
tim='66600'
label='2004-03-07-1800'
drawGraph(tim,label)
tim='66700'
label='2004-03-07-1900'
drawGraph(tim,label)
tim='66800'
label='2004-03-07-2000'
drawGraph(tim,label)
tim='66900'
label='2004-03-07-2100'
drawGraph(tim,label)
tim='67000'
label='2004-03-07-2200'
drawGraph(tim,label)
tim='67100'
label='2004-03-07-2300'
drawGraph(tim,label)

#print surftemp
#print utcitemp
#print daysAndTimes
fig = plt.figure()
fig.set_dpi(100)
fig.set_size_inches(15.36, 9.00)


plt.title("PrestonBase8 observations vs. VTUF - " + label)
plt.ylabel("temp C")
plt.grid(True)
#plt.show()
plt.savefig('Comparison' + tim + '_' + label + '.png')
plt.close()



daysAndTimes=[]

tim='67200'
label='2004-03-08-0000'
drawGraph(tim,label)
tim='67300'
label='2004-03-08-0100'
drawGraph(tim,label)
tim='67400'
label='2004-03-08-0200'
drawGraph(tim,label)
tim='67500'
label='2004-03-08-0300'
drawGraph(tim,label)
tim='67600'
label='2004-03-08-0400'
drawGraph(tim,label)
tim='67700'
label='2004-03-08-0500'
drawGraph(tim,label)
tim='67800'
label='2004-03-08-0600'
drawGraph(tim,label)
tim='67900'
label='2004-03-08-0700'
drawGraph(tim,label)
tim='68000'
label='2004-03-08-0800'
drawGraph(tim,label)
tim='68100'
label='2004-03-08-0900'
drawGraph(tim,label)
tim='68200'
label='2004-03-08-1000'
drawGraph(tim,label)
tim='68300'
label='2004-03-08-1100'
drawGraph(tim,label)
tim='68400'
label='2004-03-08-1200'
drawGraph(tim,label)
tim='68500'
label='2004-03-08-1300'
drawGraph(tim,label)
tim='68600'
label='2004-03-08-1400'
drawGraph(tim,label)
tim='68700'
label='2004-03-08-1500'
drawGraph(tim,label)
tim='68800'
label='2004-03-08-1600'
drawGraph(tim,label)
tim='68900'
label='2004-03-08-1700'
drawGraph(tim,label)
tim='69000'
label='2004-03-08-1800'
drawGraph(tim,label)
tim='69100'
label='2004-03-08-1900'
drawGraph(tim,label)
tim='69200'
label='2004-03-08-2000'
drawGraph(tim,label)
tim='69300'
label='2004-03-08-2100'
drawGraph(tim,label)
tim='69400'
label='2004-03-08-2200'
drawGraph(tim,label)
tim='69500'
label='2004-03-08-2300'
drawGraph(tim,label)

#print surftemp
#print utcitemp
#print daysAndTimes
fig = plt.figure()
fig.set_dpi(100)
fig.set_size_inches(15.36, 9.00)


plt.title("PrestonBase8 observations vs. VTUF - " + label)
plt.ylabel("temp C")
plt.grid(True)
#plt.show()
plt.savefig('Comparison' + tim + '_' + label + '.png')
plt.close()



daysAndTimes=[]

tim='69600'
label='2004-03-09-0000'
drawGraph(tim,label)
tim='69700'
label='2004-03-09-0100'
drawGraph(tim,label)
tim='69800'
label='2004-03-09-0200'
drawGraph(tim,label)
tim='69900'
label='2004-03-09-0300'
drawGraph(tim,label)
tim='70000'
label='2004-03-09-0400'
drawGraph(tim,label)
tim='70100'
label='2004-03-09-0500'
drawGraph(tim,label)
tim='70200'
label='2004-03-09-0600'
drawGraph(tim,label)
tim='70300'
label='2004-03-09-0700'
drawGraph(tim,label)
tim='70400'
label='2004-03-09-0800'
drawGraph(tim,label)
tim='70500'
label='2004-03-09-0900'
drawGraph(tim,label)
tim='70600'
label='2004-03-09-1000'
drawGraph(tim,label)
tim='70700'
label='2004-03-09-1100'
drawGraph(tim,label)
tim='70800'
label='2004-03-09-1200'
drawGraph(tim,label)
tim='70900'
label='2004-03-09-1300'
drawGraph(tim,label)
tim='71000'
label='2004-03-09-1400'
drawGraph(tim,label)
tim='71100'
label='2004-03-09-1500'
drawGraph(tim,label)
tim='71200'
label='2004-03-09-1600'
drawGraph(tim,label)
tim='71300'
label='2004-03-09-1700'
drawGraph(tim,label)
tim='71400'
label='2004-03-09-1800'
drawGraph(tim,label)
tim='71500'
label='2004-03-09-1900'
drawGraph(tim,label)
tim='71600'
label='2004-03-09-2000'
drawGraph(tim,label)
tim='71700'
label='2004-03-09-2100'
drawGraph(tim,label)
tim='71800'
label='2004-03-09-2200'
drawGraph(tim,label)
tim='71900'
label='2004-03-09-2300'
drawGraph(tim,label)

#print surftemp
#print utcitemp
#print daysAndTimes
fig = plt.figure()
fig.set_dpi(100)
fig.set_size_inches(15.36, 9.00)


plt.title("PrestonBase8 observations vs. VTUF - " + label)
plt.ylabel("temp C")
plt.grid(True)
#plt.show()
plt.savefig('Comparison' + tim + '_' + label + '.png')
plt.close()



daysAndTimes=[]


drawAggGraphs()

