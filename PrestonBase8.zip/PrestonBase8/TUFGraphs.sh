R CMD BATCH TUFGraphs.R
R CMD BATCH TUF_ave_graphs.R

