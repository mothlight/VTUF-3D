BASEFILES=" run.sh grid_run.sh MatlabPatchesPlot3.py parameters.dat veght.dat bldht.dat  MatlabPatchesPlot4.py run_script_py.sh TUF_ave_graphs.R vegtype.dat forcing.dat MatlabPatchesPlot6.py run_script.sh  TUFGraphs.R GenerateUTCIFiles.py MatlabPatchesPlot8.py treemap.dat TUFGraphs.sh treenumber.dat UTCI.py "

cd ~/Documents/Work/VTUF-Runs/LincolnScenarios/LincolnSqScenario3-GrassTreeRoad
CON=`find . -iname "confile.dat" -print`
WATBAL=`find . -iname "watbal.dat" -print`
WATPARS=`find . -iname "watpars.dat" -print`
DAYFLX=`find . -iname "Dayflx.dat" -print`
PHY=`find . -iname "phy1.dat" -print`
TESTFLX=`find . -iname "testflx.dat" -print`
USPAR=`find . -iname "uspar.dat" -print`
WATBALDAY=`find . -iname "watbalday.dat" -print`
HRFLUX=`find . -iname "hrflux.dat" -print`
POINTS=`find . -iname "points.dat" -print`
STR=`find . -iname "str1.dat" -print`
TREES=`find . -iname "trees.dat" -print`

FILES=$BASEFILES' '$CON' '$WATBAL' '$WATPARS' '$DAYFLX' '$PHY' '$TESTFLX' '$USPAR' '$WATBALDAY' '$HRFLUX' '$POINTS' '$STR' '$TREES' '

tar cfj pack.tar.bz2 $FILES

scp pack.tar.bz2  grid3:/nfs-tmp/home/kerryn/VTUF_Runs/PrestonBase/PrestonBase8/
rm pack.tar.bz2

